export default userJoin = (id, username, room) {
    const user = {
        type: 'NEW_USER',
        id,
        userName,
        room,
    }
    // users.push(user)

    return user
}