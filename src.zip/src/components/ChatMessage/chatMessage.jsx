import React, { Component } from 'react';


class ChatMessage extends Component {

    render() {
        return (<div class="chat-messages">

        </div>)
    }
}

export default ChatMessage;